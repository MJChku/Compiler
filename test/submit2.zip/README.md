implementation : 
	instructions are created as a linked list so that instruction can be excuted stmt by stmt; 
        large effort is put on repeat function call, aims to repeat.
        linked list seems not working. ( i have to do it reversely after a long time debugging so the input is actually reverse);
