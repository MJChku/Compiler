
typedef struct inst{
  int name;
  int param[6];
  int size;
  struct inst* next;
  struct inst* block;

} instruction;


