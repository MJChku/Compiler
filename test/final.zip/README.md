implementation : 
	instructions are created as a linked list so that instruction can be excuted stmt by stmt; 
        large effort is put on repeat function call, aims to repeat BUT linked list seems not working, so i did reversely(add onto head).
        so input file has to write from buttom to top;


line takes 4 parameter;


line_ takes 2 parameter; // start is current position of cursor

draw: is the same;

display : display the board;

repeat(i){ stmts }  : takes an integer, and stmts   
