Function
   decleration are treated the sameway as variables ( maximum length 12).
   you can declear anywhere in the  program.  
   you can use function_name (variable, "string", 'char', 5 ) to  call the function.
   caution: please indicate a return.
   recursion is supported
   function support variable shadowing, or actually no variable outside function will work inside. Hence, you can use
     the same name both as argument or parameter.
   flaws:
      stack area for store local variables are hard coded to 20;

flaws:
   { } doesn't support variable shadowing.

   
